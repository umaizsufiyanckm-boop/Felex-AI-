package com.felex.ai;

// FelexMainActivity.java — Felex AI Android Controller
// Embeds a local HTTP server that receives commands from the Python backend.
// Uses NanoHTTPD for the lightweight server.
// Add to build.gradle: implementation 'org.nanohttpd:nanohttpd:2.3.1'

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.AlarmClock;
import android.media.AudioManager;
import android.content.Context;
import android.widget.TextView;
import android.widget.Toast;
import android.util.Log;

import org.json.JSONObject;
import fi.iki.elonen.NanoHTTPD;

import java.io.IOException;
import java.util.Map;

public class FelexMainActivity extends Activity {

    private static final String TAG = "FelexAI";
    private static final int PORT = 8765;
    private FelexServer server;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        TextView statusText = findViewById(R.id.statusText);

        try {
            server = new FelexServer(PORT, this);
            server.start();
            statusText.setText("⚡ Felex AI is active on port " + PORT);
            Log.i(TAG, "Felex server started on port " + PORT);
        } catch (IOException e) {
            statusText.setText("❌ Failed to start server: " + e.getMessage());
            Log.e(TAG, "Server start failed", e);
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (server != null) server.stop();
    }

    // ─── Embedded HTTP Server ───────────────────────────────────

    class FelexServer extends NanoHTTPD {

        private final Context ctx;

        FelexServer(int port, Context context) {
            super(port);
            this.ctx = context;
        }

        @Override
        public Response serve(IHTTPSession session) {
            String uri = session.getUri().replaceFirst("/", "");
            JSONObject body = parseBody(session);
            String result;

            runOnUiThread(() ->
                Toast.makeText(ctx, "Command: " + uri, Toast.LENGTH_SHORT).show()
            );

            switch (uri) {
                case "call":      result = handleCall(body);       break;
                case "sms":       result = handleSms(body);        break;
                case "open_app":  result = handleOpenApp(body);    break;
                case "alarm":     result = handleAlarm(body);      break;
                case "timer":     result = handleTimer(body);      break;
                case "volume":    result = handleVolume(body);     break;
                case "screenshot":result = handleScreenshot();     break;
                case "health":    result = "Felex Android online"; break;
                default:          result = "Unknown command: " + uri;
            }

            return newFixedLengthResponse(buildResponse(result));
        }

        private String handleCall(JSONObject body) {
            try {
                String contact = body.getString("contact");
                Intent intent = new Intent(Intent.ACTION_DIAL);
                intent.setData(Uri.parse("tel:" + Uri.encode(contact)));
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                ctx.startActivity(intent);
                return "Calling " + contact;
            } catch (Exception e) { return "Call failed: " + e.getMessage(); }
        }

        private String handleSms(JSONObject body) {
            try {
                String contact = body.getString("contact");
                String message = body.getString("message");
                Intent intent = new Intent(Intent.ACTION_SENDTO);
                intent.setData(Uri.parse("smsto:" + Uri.encode(contact)));
                intent.putExtra("sms_body", message);
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                ctx.startActivity(intent);
                return "Message to " + contact + " prepared.";
            } catch (Exception e) { return "SMS failed: " + e.getMessage(); }
        }

        private String handleOpenApp(JSONObject body) {
            try {
                String appName = body.getString("app").toLowerCase();
                // Map common names to package names
                Map<String, String> apps = Map.of(
                    "youtube", "com.google.android.youtube",
                    "spotify", "com.spotify.music",
                    "maps", "com.google.android.apps.maps",
                    "chrome", "com.android.chrome",
                    "settings", "com.android.settings",
                    "camera", "com.android.camera2",
                    "calculator", "com.android.calculator2"
                );
                String pkg = apps.getOrDefault(appName, null);
                if (pkg != null) {
                    Intent intent = ctx.getPackageManager().getLaunchIntentForPackage(pkg);
                    if (intent != null) {
                        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                        ctx.startActivity(intent);
                        return "Opened " + appName;
                    }
                }
                return "App not found: " + appName;
            } catch (Exception e) { return "Open app failed: " + e.getMessage(); }
        }

        private String handleAlarm(JSONObject body) {
            try {
                String timeStr = body.getString("time");
                Intent intent = new Intent(AlarmClock.ACTION_SET_ALARM);
                intent.putExtra(AlarmClock.EXTRA_MESSAGE, "Felex Alarm");
                intent.putExtra(AlarmClock.EXTRA_SKIP_UI, false);
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                ctx.startActivity(intent);
                return "Alarm set for " + timeStr;
            } catch (Exception e) { return "Alarm failed: " + e.getMessage(); }
        }

        private String handleTimer(JSONObject body) {
            try {
                String duration = body.getString("duration");
                Intent intent = new Intent(AlarmClock.ACTION_SET_TIMER);
                intent.putExtra(AlarmClock.EXTRA_MESSAGE, "Felex Timer");
                intent.putExtra(AlarmClock.EXTRA_SKIP_UI, false);
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                ctx.startActivity(intent);
                return "Timer set for " + duration;
            } catch (Exception e) { return "Timer failed: " + e.getMessage(); }
        }

        private String handleVolume(JSONObject body) {
            try {
                AudioManager audio = (AudioManager) ctx.getSystemService(Context.AUDIO_SERVICE);
                if (body.has("level")) {
                    int max = audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC);
                    int level = (int)(body.getInt("level") / 100.0 * max);
                    audio.setStreamVolume(AudioManager.STREAM_MUSIC, level, 0);
                    return "Volume set to " + body.getInt("level") + "%";
                }
                return "Volume command received.";
            } catch (Exception e) { return "Volume failed: " + e.getMessage(); }
        }

        private String handleScreenshot() {
            // Screenshot requires Accessibility Service or MediaProjection API
            return "Screenshot: use Android Accessibility Service for full support.";
        }

        private JSONObject parseBody(IHTTPSession session) {
            try {
                Map<String, String> bodyMap = new java.util.HashMap<>();
                session.parseBody(bodyMap);
                String body = bodyMap.getOrDefault("postData", "{}");
                return new JSONObject(body);
            } catch (Exception e) {
                return new JSONObject();
            }
        }

        private String buildResponse(String message) {
            try {
                JSONObject obj = new JSONObject();
                obj.put("message", message);
                return obj.toString();
            } catch (Exception e) {
                return "{\"message\": \"error\"}";
            }
        }
    }
}
