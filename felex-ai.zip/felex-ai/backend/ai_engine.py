"""
backend/ai_engine.py — Felex AI Engine
Uses OpenRouter API. Configure your key and model in APP_SETTINGS below.
"""

import requests

# ─── App Settings ─────────────────────────────────────────────
# Set your OpenRouter API key and preferred model ID here
APP_SETTINGS = {
    "openrouter_api_key": "YOUR_OPENROUTER_API_KEY_HERE",  # Paste your OpenRouter key here
    "openrouter_model":   "openai/gpt-4o-mini",            # Change model ID here e.g. "anthropic/claude-3-haiku"
}

OPENROUTER_URL = "https://openrouter.ai/api/v1/chat/completions"

SYSTEM_PROMPT = """You are Felex, a smart, friendly, and concise AI assistant.
You help users with tasks, answer questions, control their Android device when asked,
and provide clear, helpful responses. Keep replies brief unless detail is needed.
If you detect a device control request (call, text, open app, alarm, etc.),
acknowledge it clearly so the command router can handle it."""


def get_ai_response(user_message: str, history: list = None) -> str:
    api_key = APP_SETTINGS.get("openrouter_api_key", "")
    model   = APP_SETTINGS.get("openrouter_model", "openai/gpt-4o-mini")

    if not api_key or api_key == "YOUR_OPENROUTER_API_KEY_HERE":
        return "⚠️ No OpenRouter API key set. Edit APP_SETTINGS in ai_engine.py."

    messages = [{"role": "system", "content": SYSTEM_PROMPT}]
    if history:
        messages.extend(history)
    messages.append({"role": "user", "content": user_message})

    try:
        resp = requests.post(
            OPENROUTER_URL,
            headers={
                "Authorization": f"Bearer {api_key}",
                "Content-Type": "application/json",
                "HTTP-Referer": "https://felex-ai.local",
                "X-Title": "Felex AI",
            },
            json={
                "model": model,
                "messages": messages,
                "max_tokens": 512,
                "temperature": 0.7,
            },
            timeout=15,
        )
        data = resp.json()
        return data["choices"][0]["message"]["content"].strip()

    except Exception as e:
        return f"⚠️ AI engine error: {str(e)}"
