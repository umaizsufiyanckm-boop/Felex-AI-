// chat.js — Felex AI Chat Controller

const BACKEND_URL = "http://localhost:5000/chat";

const chatWindow = document.getElementById("chatWindow");
const userInput = document.getElementById("userInput");
const sendBtn = document.getElementById("sendBtn");
const micBtn = document.getElementById("micBtn");
const statusEl = document.getElementById("status");

// ─── UI Helpers ───────────────────────────────────────────────

function appendMessage(role, text) {
  const msgEl = document.createElement("div");
  msgEl.className = `message ${role}`;
  const bubble = document.createElement("div");
  bubble.className = "bubble";
  bubble.textContent = text;
  msgEl.appendChild(bubble);
  chatWindow.appendChild(msgEl);
  chatWindow.scrollTop = chatWindow.scrollHeight;
  return msgEl;
}

function showTyping() {
  const el = document.createElement("div");
  el.className = "message bot typing-indicator";
  el.id = "typing";
  el.innerHTML = `<div class="bubble"><span class="dot"></span><span class="dot"></span><span class="dot"></span></div>`;
  chatWindow.appendChild(el);
  chatWindow.scrollTop = chatWindow.scrollHeight;
}

function removeTyping() {
  const el = document.getElementById("typing");
  if (el) el.remove();
}

function setStatus(text, cls = "") {
  statusEl.textContent = text;
  statusEl.className = "status " + cls;
}

// ─── ElevenLabs Audio Playback ────────────────────────────────

function playAudio(base64Mp3) {
  if (!base64Mp3) return;
  const audio = new Audio("data:audio/mpeg;base64," + base64Mp3);
  audio.play().catch(e => {
    // Fallback to browser TTS if autoplay blocked
    console.warn("Audio play blocked, falling back to browser TTS:", e);
  });
}

// ─── Send Message ─────────────────────────────────────────────

async function sendMessage(text) {
  if (!text.trim()) return;

  appendMessage("user", text);
  userInput.value = "";
  showTyping();
  setStatus("Thinking...");

  try {
    const res = await fetch(BACKEND_URL, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ message: text, tts: true }),
    });

    const data = await res.json();
    removeTyping();

    const reply = data.reply || "I didn't get a response.";
    const role = data.type === "command" ? "system" : "bot";

    appendMessage(role, reply);

    // Play ElevenLabs audio if available, else fall back to browser TTS
    if (data.audio) {
      playAudio(data.audio);
    } else {
      Voice.speak(reply);
    }

    setStatus("Ready");
  } catch (err) {
    removeTyping();
    appendMessage("system", "⚠️ Cannot reach Felex backend. Is the server running?");
    setStatus("Offline");
  }
}

// ─── Event Listeners ─────────────────────────────────────────

sendBtn.addEventListener("click", () => sendMessage(userInput.value));

userInput.addEventListener("keydown", (e) => {
  if (e.key === "Enter") sendMessage(userInput.value);
});

// ─── Voice Integration ────────────────────────────────────────

const voiceReady = Voice.init(
  (transcript) => {
    userInput.value = transcript;
    sendMessage(transcript);
  },
  () => {
    micBtn.classList.remove("active");
    setStatus("Ready");
  }
);

micBtn.addEventListener("click", () => {
  if (!voiceReady) {
    appendMessage("system", "⚠️ Voice input is not supported in this browser.");
    return;
  }
  if (micBtn.classList.contains("active")) {
    Voice.stop();
  } else {
    micBtn.classList.add("active");
    setStatus("Listening...", "listening");
    Voice.start();
  }
});

window.speechSynthesis?.getVoices();
