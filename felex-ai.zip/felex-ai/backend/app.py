"""
backend/app.py — Felex AI Backend Server
Handles chat requests, routes to AI provider, detects commands,
performs Google searches, and generates ElevenLabs voice responses.
"""

from flask import Flask, request, jsonify
from flask_cors import CORS
from ai_engine import get_ai_response
from command_router import detect_and_execute
from tts_engine import speak_text_base64
from search_engine import google_search, should_search

app = Flask(__name__)
CORS(app)


@app.route("/chat", methods=["POST"])
def chat():
    data = request.get_json()
    user_message = data.get("message", "").strip()
    use_tts = data.get("tts", True)  # Client can opt out of TTS

    if not user_message:
        return jsonify({"reply": "I didn't receive any message.", "type": "error"}), 400

    # 1. Check for device command first
    command_result = detect_and_execute(user_message)
    if command_result:
        audio = speak_text_base64(command_result) if use_tts else None
        return jsonify({"reply": command_result, "type": "command", "audio": audio})

    # 2. Check if a Google search is needed
    if should_search(user_message):
        search_results = google_search(user_message)
        # Feed search results into AI for a natural response
        enriched = f"User asked: {user_message}\n\nSearch results:\n{search_results}\n\nAnswer naturally based on these results."
        reply = get_ai_response(enriched)
    else:
        # 3. Plain AI response
        reply = get_ai_response(user_message)

    # 4. Generate ElevenLabs voice audio
    audio = speak_text_base64(reply) if use_tts else None

    return jsonify({"reply": reply, "type": "message", "audio": audio})


@app.route("/speak", methods=["POST"])
def speak():
    """Standalone TTS endpoint — accepts text, returns base64 MP3."""
    data = request.get_json()
    text = data.get("text", "").strip()
    if not text:
        return jsonify({"error": "No text provided"}), 400
    audio = speak_text_base64(text)
    if audio:
        return jsonify({"audio": audio})
    return jsonify({"error": "TTS failed"}), 500


@app.route("/search", methods=["POST"])
def search():
    """Standalone search endpoint."""
    data = request.get_json()
    query = data.get("query", "").strip()
    if not query:
        return jsonify({"error": "No query provided"}), 400
    results = google_search(query)
    return jsonify({"results": results})


@app.route("/health", methods=["GET"])
def health():
    return jsonify({"status": "ok", "assistant": "Felex AI", "services": ["openrouter", "elevenlabs", "serpapi"]})


if __name__ == "__main__":
    print("⚡ Felex AI backend running at http://localhost:5000")
    app.run(host="0.0.0.0", port=5000, debug=True)
