"""
backend/tts_engine.py — Felex AI Text-to-Speech via ElevenLabs
Uses ElevenLabs turbo model for fast, natural voice output.
Audio is returned as bytes and played via the /speak endpoint.
"""

import requests
import base64

# ─── ElevenLabs Config ────────────────────────────────────────
ELEVENLABS_API_KEY = "sk_91bdf20a9b1fbfa80423eb20137673cb0ec8dd6a37855ba4"
ELEVENLABS_MODEL   = "eleven_turbo_v2_5"
ELEVENLABS_VOICE   = "21m00Tcm4TlvDq8ikWAM"  # Default: "Rachel" — change voice ID here

ELEVENLABS_URL = f"https://api.elevenlabs.io/v1/text-to-speech/{ELEVENLABS_VOICE}"


def speak_text(text: str) -> bytes | None:
    """
    Convert text to speech using ElevenLabs.
    Returns raw MP3 audio bytes, or None on failure.
    """
    try:
        resp = requests.post(
            ELEVENLABS_URL,
            headers={
                "xi-api-key": ELEVENLABS_API_KEY,
                "Content-Type": "application/json",
            },
            json={
                "text": text,
                "model_id": ELEVENLABS_MODEL,
                "voice_settings": {
                    "stability": 0.5,
                    "similarity_boost": 0.75,
                    "style": 0.0,
                    "use_speaker_boost": True,
                },
            },
            timeout=10,
        )

        if resp.status_code == 200:
            return resp.content  # Raw MP3 bytes
        else:
            print(f"ElevenLabs error {resp.status_code}: {resp.text}")
            return None

    except Exception as e:
        print(f"TTS error: {e}")
        return None


def speak_text_base64(text: str) -> str | None:
    """
    Returns base64-encoded MP3 audio string (for sending to browser via JSON).
    """
    audio = speak_text(text)
    if audio:
        return base64.b64encode(audio).decode("utf-8")
    return None
