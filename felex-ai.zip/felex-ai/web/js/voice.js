// voice.js — Felex AI Voice Input & Output Module

const Voice = (() => {
  const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
  let recognition = null;
  let isListening = false;

  function init(onResult, onEnd) {
    if (!SpeechRecognition) {
      console.warn("Speech Recognition not supported in this browser.");
      return false;
    }

    recognition = new SpeechRecognition();
    recognition.lang = "en-US";
    recognition.interimResults = false;
    recognition.maxAlternatives = 1;

    recognition.onresult = (event) => {
      const transcript = event.results[0][0].transcript;
      onResult(transcript);
    };

    recognition.onend = () => {
      isListening = false;
      onEnd();
    };

    recognition.onerror = (event) => {
      console.error("Voice error:", event.error);
      isListening = false;
      onEnd();
    };

    return true;
  }

  function start() {
    if (recognition && !isListening) {
      recognition.start();
      isListening = true;
    }
  }

  function stop() {
    if (recognition && isListening) {
      recognition.stop();
    }
  }

  function speak(text, options = {}) {
    if (!window.speechSynthesis) return;

    // Cancel any ongoing speech
    window.speechSynthesis.cancel();

    const utterance = new SpeechSynthesisUtterance(text);
    utterance.lang = options.lang || "en-US";
    utterance.rate = options.rate || 1.0;
    utterance.pitch = options.pitch || 1.0;
    utterance.volume = options.volume || 1.0;

    // Try to use a natural voice
    const voices = window.speechSynthesis.getVoices();
    const preferred = voices.find(v =>
      v.name.includes("Google") || v.name.includes("Natural") || v.lang === "en-US"
    );
    if (preferred) utterance.voice = preferred;

    window.speechSynthesis.speak(utterance);
  }

  function isSupported() {
    return !!SpeechRecognition;
  }

  return { init, start, stop, speak, isSupported };
})();
