"""
backend/search_engine.py — Felex AI Google Search
Uses SerpApi to perform real-time Google searches.
Called when user asks questions that need current/live info.
"""

import requests

# ─── SerpApi Config ───────────────────────────────────────────
SERPAPI_KEY = "aGp19hVBuTR9wjhRroWQP63L"
SERPAPI_URL = "https://serpapi.com/search"


def google_search(query: str, num_results: int = 5) -> str:
    """
    Search Google via SerpApi and return a formatted summary string.
    """
    try:
        resp = requests.get(
            SERPAPI_URL,
            params={
                "q": query,
                "api_key": SERPAPI_KEY,
                "num": num_results,
                "hl": "en",
                "gl": "us",
            },
            timeout=10,
        )

        data = resp.json()

        if "error" in data:
            return f"⚠️ Search error: {data['error']}"

        results = []

        # Answer box (direct answer if available)
        if "answer_box" in data:
            box = data["answer_box"]
            answer = box.get("answer") or box.get("snippet") or box.get("result")
            if answer:
                return f"🔍 {answer}"

        # Organic results
        organic = data.get("organic_results", [])
        for item in organic[:num_results]:
            title   = item.get("title", "")
            snippet = item.get("snippet", "")
            link    = item.get("link", "")
            if snippet:
                results.append(f"• {title}: {snippet}\n  {link}")

        if results:
            return "🔍 Search results:\n\n" + "\n\n".join(results)

        return "No results found."

    except Exception as e:
        return f"⚠️ Search failed: {str(e)}"


def should_search(message: str) -> bool:
    """
    Simple heuristic: detect if a message needs a live web search.
    """
    search_triggers = [
        "search", "look up", "google", "find", "what is", "who is",
        "latest", "news", "current", "today", "price of", "weather",
        "when did", "how much", "where is", "tell me about",
    ]
    msg = message.lower()
    return any(trigger in msg for trigger in search_triggers)
