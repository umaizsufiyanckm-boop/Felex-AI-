"""
backend/android_bridge.py — Felex AI Android Bridge
Communicates with the Felex Android app via HTTP.
The Android app runs a local server and listens for commands.
"""

import requests

ANDROID_HOST = "http://192.0.0.4:8765"
TIMEOUT = 5  # seconds


def _post(endpoint: str, payload: dict = None) -> str:
    """Send a POST request to the Android app bridge."""
    try:
        resp = requests.post(
            f"{ANDROID_HOST}/{endpoint}",
            json=payload or {},
            timeout=TIMEOUT,
        )
        data = resp.json()
        return data.get("message", "✅ Done.")
    except requests.ConnectionError:
        return "⚠️ Android device not reachable. Make sure Felex is running on your phone."
    except requests.Timeout:
        return "⚠️ Android device timed out."
    except Exception as e:
        return f"⚠️ Bridge error: {str(e)}"


class AndroidBridge:

    @staticmethod
    def call(contact: str) -> str:
        return _post("call", {"contact": contact})

    @staticmethod
    def send_sms(contact: str, message: str) -> str:
        return _post("sms", {"contact": contact, "message": message})

    @staticmethod
    def open_app(app_name: str) -> str:
        return _post("open_app", {"app": app_name})

    @staticmethod
    def set_alarm(time_str: str) -> str:
        return _post("alarm", {"time": time_str})

    @staticmethod
    def set_timer(duration: str) -> str:
        return _post("timer", {"duration": duration})

    @staticmethod
    def set_volume(level) -> str:
        return _post("volume", {"level": level})

    @staticmethod
    def set_brightness(level: str) -> str:
        return _post("brightness", {"level": level})

    @staticmethod
    def set_wifi(enable: bool) -> str:
        return _post("wifi", {"enable": enable})

    @staticmethod
    def set_bluetooth(enable: bool) -> str:
        return _post("bluetooth", {"enable": enable})

    @staticmethod
    def screenshot() -> str:
        return _post("screenshot")
