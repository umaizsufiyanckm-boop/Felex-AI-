"""
backend/command_router.py — Felex AI Command Router
Detects command-style messages and routes them to appropriate handlers.
Commands can trigger Android bridge actions, local OS commands, etc.
"""

import re
from android_bridge import AndroidBridge

# ─── Command Pattern Definitions ──────────────────────────────

COMMANDS = [
    {
        "name": "call",
        "patterns": [r"call (.+)", r"phone (.+)", r"dial (.+)"],
        "handler": lambda m: AndroidBridge.call(m.group(1).strip()),
    },
    {
        "name": "text",
        "patterns": [r"(?:text|send (?:a )?(?:text|message) to) (.+?) (?:saying|:) (.+)"],
        "handler": lambda m: AndroidBridge.send_sms(m.group(1).strip(), m.group(2).strip()),
    },
    {
        "name": "open_app",
        "patterns": [r"open (?:the )?(.+?) app", r"launch (.+)"],
        "handler": lambda m: AndroidBridge.open_app(m.group(1).strip()),
    },
    {
        "name": "set_alarm",
        "patterns": [r"set (?:an )?alarm (?:for )?(.+)", r"wake me (?:up )?at (.+)"],
        "handler": lambda m: AndroidBridge.set_alarm(m.group(1).strip()),
    },
    {
        "name": "set_timer",
        "patterns": [r"set (?:a )?timer (?:for )?(.+)", r"timer (?:for )?(.+)"],
        "handler": lambda m: AndroidBridge.set_timer(m.group(1).strip()),
    },
    {
        "name": "volume",
        "patterns": [r"(?:set )?volume to (\d+)", r"turn (?:the )?volume (?:up|down)"],
        "handler": lambda m: AndroidBridge.set_volume(m.group(1) if m.lastindex else None),
    },
    {
        "name": "brightness",
        "patterns": [r"(?:set )?brightness to (\d+)"],
        "handler": lambda m: AndroidBridge.set_brightness(m.group(1).strip()),
    },
    {
        "name": "wifi",
        "patterns": [r"turn (on|off) (?:the )?wi-?fi", r"wi-?fi (on|off)"],
        "handler": lambda m: AndroidBridge.set_wifi(m.group(1).strip().lower() == "on"),
    },
    {
        "name": "bluetooth",
        "patterns": [r"turn (on|off) bluetooth", r"bluetooth (on|off)"],
        "handler": lambda m: AndroidBridge.set_bluetooth(m.group(1).strip().lower() == "on"),
    },
    {
        "name": "screenshot",
        "patterns": [r"take (?:a )?screenshot"],
        "handler": lambda m: AndroidBridge.screenshot(),
    },
]


# ─── Detector ─────────────────────────────────────────────────

def detect_and_execute(message: str):
    """
    Check if message matches a known command pattern.
    Returns the command result string if matched, or None.
    """
    msg = message.lower().strip()

    for cmd in COMMANDS:
        for pattern in cmd["patterns"]:
            match = re.search(pattern, msg, re.IGNORECASE)
            if match:
                try:
                    result = cmd["handler"](match)
                    return result or f"✅ Command '{cmd['name']}' executed."
                except Exception as e:
                    return f"⚠️ Command failed: {str(e)}"

    return None  # No command matched — let AI handle it
