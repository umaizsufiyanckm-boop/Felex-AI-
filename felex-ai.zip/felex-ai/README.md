# ⚡ Felex AI — Modular Voice Assistant

A modular AI assistant with a web chat UI, voice input/output, Python AI backend, command detection, and Android device control.

---

## Project Structure

```
felex-ai/
├── web/                        # Web chat interface
│   ├── index.html              # Main UI
│   ├── css/style.css           # Styles
│   └── js/
│       ├── voice.js            # Voice input & output (Web Speech API)
│       └── chat.js             # Chat controller
│
├── backend/                    # Python AI server
│   ├── app.py                  # Flask server (main entry point)
│   ├── ai_engine.py            # LLM integration (OpenAI GPT-4o-mini)
│   ├── command_router.py       # Command pattern detection & routing
│   ├── android_bridge.py       # HTTP client → Android app
│   ├── requirements.txt
│   └── .env.example
│
└── android/                    # Android controller app
    ├── FelexMainActivity.java  # Activity + embedded HTTP server
    ├── AndroidManifest.xml
    ├── build.gradle
    └── res/layout/activity_main.xml
```

---

## Quick Start

### 1. Backend

```bash
cd backend
pip install -r requirements.txt
cp .env.example .env
# Edit .env — add your OPENAI_API_KEY
python app.py
```

Server starts at `http://localhost:5000`

### 2. Web UI

Open `web/index.html` in any modern browser.
- Type or click 🎤 to speak
- Responses are spoken aloud via text-to-speech

### 3. Android App

1. Open in Android Studio
2. Set your phone's local IP in `android_bridge.py` (`ANDROID_HOST`)
3. Run on your device (keep app open in foreground)
4. The app listens on port **8765** for commands

---

## Voice Commands

Say or type any of these:

| Command | Example |
|---|---|
| Make a call | "Call Mom" |
| Send a text | "Text John saying I'm on my way" |
| Open an app | "Open the YouTube app" |
| Set an alarm | "Set an alarm for 7am" |
| Set a timer | "Set a timer for 10 minutes" |
| Adjust volume | "Set volume to 50" |
| Toggle WiFi | "Turn off WiFi" |
| Toggle Bluetooth | "Turn on Bluetooth" |
| Take screenshot | "Take a screenshot" |

Anything else goes to the AI for a natural language response.

---

## Configuration

### Changing the AI Provider

Edit `backend/ai_engine.py` — swap `openai` for any other provider (Anthropic, Google, Ollama, etc.).

### Adding Commands

Add entries to the `COMMANDS` list in `backend/command_router.py`:

```python
{
    "name": "my_command",
    "patterns": [r"do something (.+)"],
    "handler": lambda m: AndroidBridge.my_method(m.group(1)),
}
```

### Android Device IP

Update `ANDROID_HOST` in `backend/android_bridge.py` to your phone's local Wi-Fi IP address.
Check it in: **Settings → About Phone → Status → IP Address**

---

## Architecture

```
Browser (Web UI)
   │  voice input → transcript
   │  text input
   ▼
Python Flask Backend (port 5000)
   ├── command_router.py  →  AndroidBridge  →  Android App (port 8765)
   └── ai_engine.py       →  OpenAI API
   ▼
Response → Browser → TTS spoken aloud
```

---

## Requirements

- Python 3.10+
- Modern browser (Chrome recommended for voice)
- Android 8.0+ device (for Android control)
- OpenAI API key (or replace with another LLM)
